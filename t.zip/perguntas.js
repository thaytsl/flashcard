criaCartao(
    'Geografia',
    'Qual a capital da Itália?',
    'A capital da Itália é Roma'
)

criaCartao(
    'Geografia',
    'Qual a capital da França?',
    'A capital da França é Paris'
)

criaCartao(
    'Geografia',
    'Qual a capital do Rio Grande do Sul?',
    'A capital do Rio Grande do Sul é Porto Alegre'
)

criaCartao(
    'Lingua inglesa',
    'Como se diz oi em Inglês?',
    'Oi em ingles é HI'
)